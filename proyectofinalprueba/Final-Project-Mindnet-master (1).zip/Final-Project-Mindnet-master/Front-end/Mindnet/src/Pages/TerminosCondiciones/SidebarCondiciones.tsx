import '../../global.css'

function SidebarCondiciones() {
  return (

  <>
    <div className="sidebar-condicion">
      
      <div className="sidebar-menu-condicion">

        <div className="side-condicion">
          <div className="shape-condicion">
            <h4 className="side-1condicion">Terminos y Condiciones</h4>
          </div>
        </div>

      </div>

    </div>
  </>
  );
}

export default SidebarCondiciones;